package com.example.buget_code

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {

    private lateinit var incomeInput: EditText
    private lateinit var expenseInput: EditText
    private lateinit var categoryInput: EditText
    private lateinit var totalIncomeTextView: TextView
    private lateinit var totalExpenseTextView: TextView
    private lateinit var remainingBalanceTextView: TextView
    private lateinit var addIncomeButton: Button
    private lateinit var addExpenseButton: Button
    private lateinit var expenseListView: ListView

    private var income = 0.0
    private var expenses = 0.0
    private val categoryList = mutableListOf<String>()
    private val amountList = mutableListOf<Double>()
    private val expenseList = mutableListOf<String>()
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        incomeInput = findViewById(R.id.incomeInput)
        expenseInput = findViewById(R.id.expenseInput)
        categoryInput = findViewById(R.id.categoryInput)
        totalIncomeTextView = findViewById(R.id.totalIncome)
        totalExpenseTextView = findViewById(R.id.totalExpense)
        remainingBalanceTextView = findViewById(R.id.remainingBalance)
        addIncomeButton = findViewById(R.id.addIncomeButton)
        addExpenseButton = findViewById(R.id.addExpenseButton)
        expenseListView = findViewById(R.id.expenseListView)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, expenseList)
        expenseListView.adapter = adapter

        addIncomeButton.setOnClickListener {
            val input = incomeInput.text.toString()
            if (input.isNotEmpty()) {
                income += input.toDouble()
                incomeInput.text.clear()
                updateDisplay()
            }
        }

        addExpenseButton.setOnClickListener {
            val amountText = expenseInput.text.toString()
            val categoryText = categoryInput.text.toString()

            if (amountText.isNotEmpty() && categoryText.isNotEmpty()) {
                val amount = amountText.toDouble()
                expenses += amount
                categoryList.add(categoryText)
                amountList.add(amount)
                expenseList.add("$categoryText - R%.2f".format(amount))
                adapter.notifyDataSetChanged()

                expenseInput.text.clear()
                categoryInput.text.clear()

                updateDisplay()
            }
        }

        updateDisplay()
    }

    private fun updateDisplay() {
        totalIncomeTextView.text = "Total Income: R%.2f".format(income)
        totalExpenseTextView.text = "Total Expenses: R%.2f".format(expenses)
        remainingBalanceTextView.text = "Remaining Balance: R%.2f".format(income - expenses)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.dashboard_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_graph -> {
                val intent = Intent(this, ExpenseGraphActivity::class.java)
                intent.putExtra("totalIncome", income)
                intent.putExtra("categories", categoryList.toTypedArray())
                intent.putExtra("amounts", amountList.toDoubleArray())
                startActivity(intent)
                true
            }
            R.id.menu_saving -> {
                val intent = Intent(this, SavingsSheetActivity::class.java)
                intent.putExtra("totalIncome", income)
                intent.putExtra("totalExpense", expenses)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}