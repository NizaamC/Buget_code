package com.example.buget_code

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ExpenseGraphActivity : AppCompatActivity() {

    private lateinit var graphContainer: LinearLayout
    private lateinit var goalText: TextView
    private lateinit var periodSpinner: Spinner
    private lateinit var badgeText: TextView

    private lateinit var savingsGoalInput: EditText
    private lateinit var timePeriodInput: EditText
    private lateinit var calculateSavingsButton: Button
    private lateinit var savingsResultText: TextView

    private val minGoal = 300.0
    private val maxGoal = 800.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_graph)

        graphContainer = findViewById(R.id.graphContainer)
        goalText = findViewById(R.id.goalText)
        periodSpinner = findViewById(R.id.periodSpinner)
        badgeText = findViewById(R.id.badgeText)
        savingsGoalInput = findViewById(R.id.savingsGoalInput)
        timePeriodInput = findViewById(R.id.timePeriodInput)
        calculateSavingsButton = findViewById(R.id.calculateSavingsButton)
        savingsResultText = findViewById(R.id.savingsResultText)

        val periods = arrayOf("Last Week", "Last Month")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, periods)
        periodSpinner.adapter = adapter

        val totalIncome = intent.getDoubleExtra("totalIncome", 0.0)
        val categories = intent.getStringArrayExtra("categories") ?: arrayOf()
        val amounts = intent.getDoubleArrayExtra("amounts") ?: doubleArrayOf()
        val categoryData = categories.zip(amounts.toList()).toMap()

        periodSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                graphContainer.removeAllViews()
                showBarGraph(categoryData)
                showGoalFeedback(categoryData, totalIncome)
                checkBadges(categoryData)
                highlightTopSpendingCategory(categoryData)
                showAveragePerCategory(categoryData)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        calculateSavingsButton.setOnClickListener {
            evaluateSavingsPossibility(categoryData, totalIncome)
        }
    }

    private fun showBarGraph(data: Map<String, Double>) {
        val maxAmount = data.values.maxOrNull() ?: 1.0
        for ((category, amount) in data) {
            val barRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 8, 0, 8)
            }

            val label = TextView(this).apply {
                text = "$category:"
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val bar = View(this).apply {
                val weight = (amount / maxAmount).toFloat()
                layoutParams = LinearLayout.LayoutParams(0, 40, weight)
                setBackgroundColor(if (amount in minGoal..maxGoal) Color.GREEN else Color.RED)
            }

            val amountLabel = TextView(this).apply {
                text = "R%.2f".format(amount)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setPadding(8, 0, 0, 0)
            }

            barRow.addView(label)
            barRow.addView(bar)
            barRow.addView(amountLabel)
            graphContainer.addView(barRow)
        }
    }

    private fun showGoalFeedback(data: Map<String, Double>, income: Double) {
        val totalSpent = data.values.sum()
        val message = when {
            totalSpent < minGoal -> "You're under the minimum spending goal."
            totalSpent > maxGoal -> "You've gone over the maximum budget!"
            else -> "Great job! You're within your spending goals."
        }
        goalText.text = "Total Income: R%.2f\nTotal Spent: R%.2f\n$message".format(income, totalSpent)
    }

    private fun checkBadges(data: Map<String, Double>) {
        val totalSpent = data.values.sum()
        val badge = when {
            totalSpent in minGoal..maxGoal -> "🏅 Budget Master!"
            data.size >= 5 -> "📈 Consistent Logger!"
            else -> "🔔 Keep Going!"
        }
        badgeText.text = "Badge: $badge"
    }

    private fun highlightTopSpendingCategory(data: Map<String, Double>) {
        if (data.isNotEmpty()) {
            val (topCategory, topAmount) = data.maxByOrNull { it.value }!!
            Toast.makeText(this, "You spent the most on: $topCategory (R%.2f)".format(topAmount), Toast.LENGTH_LONG).show()
        }
    }

    private fun showAveragePerCategory(data: Map<String, Double>) {
        if (data.isNotEmpty()) {
            val average = data.values.sum() / data.size
            Toast.makeText(this, "📊 Average spent per category: R%.2f".format(average), Toast.LENGTH_SHORT).show()
        }
    }

    private fun evaluateSavingsPossibility(data: Map<String, Double>, income: Double) {
        val savingsGoalText = savingsGoalInput.text.toString()
        val timePeriodText = timePeriodInput.text.toString()

        if (savingsGoalText.isBlank() || timePeriodText.isBlank()) {
            Toast.makeText(this, "Please enter both savings goal and time period.", Toast.LENGTH_SHORT).show()
            savingsResultText.text = ""
            return
        }

        val savingsGoal = savingsGoalText.toDoubleOrNull() ?: 0.0
        val timeWeeks = timePeriodText.toIntOrNull() ?: 0

        if (savingsGoal <= 0 || timeWeeks <= 0) {
            Toast.makeText(this, "Please enter valid numeric values.", Toast.LENGTH_SHORT).show()
            savingsResultText.text = ""
            return
        }

        val totalSpent = data.values.sum()
        val totalLeft = income - totalSpent
        val weeklyNeeded = savingsGoal / timeWeeks

        val result = if (totalLeft >= savingsGoal) {
            "✅ You can save R%.2f over %d weeks.\n" +
                    "You’ll have R%.2f left after expenses.\n" +
                    "You need to save about R%.2f per week.".format(
                        savingsGoal, timeWeeks, totalLeft, weeklyNeeded
                    )
        } else {
            val shortfall = savingsGoal - totalLeft
            "❌ You won’t be able to save R%.2f.\n" +
                    "You only have R%.2f left after expenses.\n" +
                    "You’re short by R%.2f.\n" +
                    "You'd need to save about R%.2f per week.".format(
                        savingsGoal, totalLeft, shortfall, weeklyNeeded
                    )
        }

        // Show in both Toast and on-screen TextView
        Toast.makeText(this, result, Toast.LENGTH_LONG).show()
        savingsResultText.text = result
    }
}
